# Aqtobe BIL Sport Time

A responsive vanilla HTML/CSS/JS rebuild based on the uploaded Sport Time 10A source and the supplied BIL logo. It keeps the useful core areas (player roster, matches, ratings/leaderboard) while removing player positions, speed-related stats, and old author branding. No player names, photos, or statistics are fabricated.

## Files
- `index.html` — frontend and Supabase integration
- `supabase.sql` — schema, group seed data, RLS policies
- `config.js.example` — environment configuration template (copy to `config.js`)
- `assets/bil-logo.webp` — logo supplied with the request

## Setup
1. Create a **new** project at https://supabase.com/dashboard.
2. Open SQL Editor, paste and run `supabase.sql`.
3. Copy `config.js.example` to `config.js`; set `SUPABASE_URL` and the project's publishable/anon key from Project Settings → API.
4. Deploy the folder to your static host (Lovable/Vercel/Netlify or any static web host). Include `config.js` and `assets/`.
5. In Supabase Authentication, create accounts for the actual users (or configure an approved school sign-in flow). Disable public sign-ups if accounts are administrator-created.
6. Add a `profiles` row for each account. The `id` must equal that account's Auth user UUID. Set `role` to `student`, `tutor`, `teacher`, or `admin`; students get their `class_code` such as `10A`. Staff roles use `Tutor` or `Teacher` as appropriate, and admins may have a null class.
7. Add real players to `players` with the exact `full_name`, `class_code`, optional `avatar_url`, and optional rating. Upload photographs to a Supabase Storage bucket and store the resulting object URL in `avatar_url`. Do not add positions or speed data.
8. Add matches to `matches` when you have real match information.

## Security notes
- The browser contains only the publishable/anon key, which is designed to be public. Never expose a service-role/secret key.
- RLS is enabled on all tables. Staff/admin write access depends on the trusted `profiles.role` row. Do not allow users to edit their own role or class.
- For production privacy, decide whether student rosters should be public. The supplied SQL allows anonymous SELECT of player rosters to support class browsing. If rosters/photos should be private, remove the anonymous part of the `read player roster` policy and require authenticated users. Also consider a private Storage bucket and policies for avatar files.
- The included policies are a practical starter, not a substitute for reviewing your school's student-data/privacy requirements. Test policies with separate student, tutor, teacher, and admin accounts before launch.

## Important limitation
I cannot create a Supabase project or deploy the website into your hosting account from this chat. You must create the project and supply its URL/key. The app will show an empty-state message until the project is configured and you enter the real roster data. No default student records are seeded.
