-- Aqtobe BIL Sport Time — Supabase SQL setup
-- Run in Supabase Dashboard > SQL Editor using a NEW project.
create extension if not exists pgcrypto;

create table if not exists public.school_groups (
  code text primary key,
  label text not null,
  group_type text not null check (group_type in ('student_class','staff')),
  created_at timestamptz not null default now()
);

insert into public.school_groups(code,label,group_type) values
('7A','Class 7A','student_class'),('7B','Class 7B','student_class'),
('8A','Class 8A','student_class'),('8B','Class 8B','student_class'),
('9A','Class 9A','student_class'),('9B','Class 9B','student_class'),
('10A','Class 10A','student_class'),('10B','Class 10B','student_class'),
('11A','Class 11A','student_class'),('11B','Class 11B','student_class'),
('Tutor','Tutors','staff'),('Teacher','Teachers','staff')
on conflict (code) do nothing;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'student' check (role in ('student','tutor','teacher','admin')),
  class_code text references public.school_groups(code),
  created_at timestamptz not null default now()
);

create table if not exists public.players (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  class_code text not null references public.school_groups(code),
  avatar_url text,
  rating numeric(5,2) check (rating is null or rating between 0 and 100),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  class_code text not null references public.school_groups(code),
  match_date date,
  sport text not null default 'Football',
  team_a text not null,
  team_b text not null,
  score_a integer check (score_a is null or score_a >= 0),
  score_b integer check (score_b is null or score_b >= 0),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create index if not exists players_class_code_idx on public.players(class_code);
create index if not exists matches_class_date_idx on public.matches(class_code, match_date desc);

create or replace function public.current_role()
returns text language sql stable security definer set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.current_class_code()
returns text language sql stable security definer set search_path = public
as $$ select class_code from public.profiles where id = auth.uid() $$;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public
as $$ select coalesce(public.current_role() in ('tutor','teacher','admin'), false) $$;

alter table public.school_groups enable row level security;
alter table public.profiles enable row level security;
alter table public.players enable row level security;
alter table public.matches enable row level security;

-- Group names are safe to show publicly.
drop policy if exists "groups are readable" on public.school_groups;
create policy "groups are readable" on public.school_groups for select using (true);

-- Users can read their own profile. Staff/admin can read profiles for school administration.
drop policy if exists "read own profile or staff" on public.profiles;
create policy "read own profile or staff" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_staff());
drop policy if exists "users update own basic profile" on public.profiles;
create policy "users update own basic profile" on public.profiles for update to authenticated
using (id = auth.uid() and role = public.current_role() and class_code is not distinct from public.current_class_code())
with check (id = auth.uid() and role = public.current_role() and class_code is not distinct from public.current_class_code());
drop policy if exists "admins manage profiles" on public.profiles;
create policy "admins manage profiles" on public.profiles for all to authenticated
using (public.current_role() = 'admin') with check (public.current_role() = 'admin');

-- Student data is private by default: authenticated students see only their own class;
-- tutors, teachers, and admins can read all rosters.
drop policy if exists "read player roster" on public.players;
create policy "read player roster" on public.players for select to authenticated using (
  public.is_staff() or class_code = public.current_class_code()
);
drop policy if exists "staff manage players" on public.players;
create policy "staff manage players" on public.players for all to authenticated
using (public.is_staff()) with check (public.is_staff());

drop policy if exists "read matches" on public.matches;
create policy "read matches" on public.matches for select to authenticated using (
  public.is_staff() or class_code = public.current_class_code()
);
drop policy if exists "staff manage matches" on public.matches;
create policy "staff manage matches" on public.matches for all to authenticated
using (public.is_staff()) with check (public.is_staff());

-- Create auth users in Dashboard > Authentication, then insert/update their profiles as an admin.
-- Never put a service-role key in frontend code.
